
python run.py \
    --function pretrain \
    --pretrain_corpus_path ./dataset/pretrain/wiki.txt \
    --outputs_path /root/autodl-tmp/output \
    --device cuda
